/*
  (c) Copyright 2018, 2019 Phasmid Software
 */
package edu.neu.coe.info6205.sort.elementary;

import edu.neu.coe.info6205.sort.BaseHelper;
import edu.neu.coe.info6205.sort.Helper;
import edu.neu.coe.info6205.sort.SortWithHelper;
import edu.neu.coe.info6205.util.Config;
import edu.neu.coe.info6205.util.Timer;

import java.util.Random;

public class InsertionSort<X extends Comparable<X>> extends SortWithHelper<X> {

    /**
     * Constructor for any sub-classes to use.
     *
     * @param description the description.
     * @param N           the number of elements expected.
     * @param config      the configuration.
     */
    protected InsertionSort(String description, int N, Config config) {
        super(description, N, config);
    }

    /**
     * Constructor for InsertionSort
     *
     * @param N      the number elements we expect to sort.
     * @param config the configuration.
     */
    public InsertionSort(int N, Config config) {
        this(DESCRIPTION, N, config);
    }

    public InsertionSort(Config config) {
        this(new BaseHelper<>(DESCRIPTION, config));
    }

    /**
     * Constructor for InsertionSort
     *
     * @param helper an explicit instance of Helper to be used.
     */
    public InsertionSort(Helper<X> helper) {
        super(helper);
    }

    public InsertionSort() {
        this(BaseHelper.getHelper(InsertionSort.class));
    }

    /**
     * Sort the sub-array xs:from:to using insertion sort.
     *
     * @param xs   sort the array xs from "from" to "to".
     * @param from the index of the first element to sort
     * @param to   the index of the first element not to sort
     */
    public void sort(X[] xs, int from, int to) {
        final Helper<X> helper = getHelper();
        // FIXME
        for(int i = from + 1; i < to; i++){
            int j = i - 1;
            while(j >= from && helper.less(xs[i], xs[j])){
                j--;
            }
            j++;
            helper.swapInto(xs, j , i);
        }
        // End
    }

    public static final String DESCRIPTION = "Insertion sort";

    public static <T extends Comparable<T>> void sort(T[] ts) {
        new InsertionSort<T>().mutatingSort(ts);
    }
    /**
     * repeat the insertion sort for n times.
     *
     * @param xs the array needs to be sorted
     * @param n the times for InsertSort repeat
     */
    private double repeatInsertionSort(int n, X[] xs) {
        InsertionSort insertionSort =new InsertionSort();
        Timer timer = new Timer();
        for (int i = 0; i < n; i++) {
            insertionSort.sort(xs, 0, xs.length);
            timer.lap();
        }
        timer.pause();
        return timer.meanLapTime();
    }

    /**
     * get the RandomArray
     *
     * @param size the size of randomArray
     */
    private static Integer[] getRandomArray(int size){
        Random random = new Random();
        Integer[] randomArray = new Integer[size];
        for(int i = 0; i < size; i++){
            randomArray[i] = random.nextInt();
        }
        return randomArray;
    }

    /**
     * get the orderedArray
     *
     * @param size the size of orderedArray
     */
    private static Integer[] getOrderedArray(int size){
        Integer[] orderedArray = new Integer[size];
        for(int i = 0; i < size; i++){
            orderedArray[i] = i;
        }
        return orderedArray;
    }

    /**
     * get the partially-ordered Array
     *
     * @param size the size of partially-ordered
     */
    private static Integer[] getPartiallyOrderedArray(int size){
        Integer[] partiallyOrderedArray = new Integer[size];
        Random random = new Random();
        for(int i = 0; i < size; i++){
            if(i < size / 2){
                partiallyOrderedArray[i] = random.nextInt();
            }else{
                partiallyOrderedArray[i] = i;
            }
        }
        return partiallyOrderedArray;
    }

    /**
     * get the reverseOrderedArray Array
     *
     * @param size the size of ReverseOrderedArray
     */
    private static Integer[] getReverseOrderedArray(int size){
        Integer[] reverseOrderedArray = new Integer[size];
        for(int i = 0; i < size; i++){
            reverseOrderedArray[i] = size - i;
        }
        return reverseOrderedArray;
    }


    public static void main(String[] args) {
        System.out.println("size of array, random, ordered, partially-ordered, reverse-ordered:");

        for(int m = 1 ;m <= 100000; m += m){
            Integer[] randomArray = getRandomArray(m);
            Integer[] orderedArray = getOrderedArray(m);
            Integer[] partiallyOrderedArray = getPartiallyOrderedArray(m);
            Integer[] reverseOrderedArray = getReverseOrderedArray(m);

            InsertionSort insertionSort = new InsertionSort();
            double time1 = insertionSort.repeatInsertionSort(10, randomArray);
            double time2 = insertionSort.repeatInsertionSort(10, orderedArray);
            double time3 = insertionSort.repeatInsertionSort(10, partiallyOrderedArray);
            double time4 = insertionSort.repeatInsertionSort(10, reverseOrderedArray);
            System.out.println(m+","+time1+","+time2+","+time3+","+time4);
        }
    }
}
