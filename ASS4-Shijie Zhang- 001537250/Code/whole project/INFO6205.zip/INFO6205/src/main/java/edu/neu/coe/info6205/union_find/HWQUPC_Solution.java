package edu.neu.coe.info6205.union_find;

public class HWQUPC_Solution {
}
